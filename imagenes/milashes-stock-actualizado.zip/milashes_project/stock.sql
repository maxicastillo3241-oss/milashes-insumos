-- Ejecutar una sola vez en Supabase > SQL Editor

create or replace function public.decrement_stock(p_items jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  item jsonb;
  product_id bigint;
  qty integer;
  new_stock integer;
  result jsonb := '[]'::jsonb;
begin
  if jsonb_typeof(p_items) <> 'array' then
    raise exception 'Los productos del pedido no son válidos.';
  end if;

  for item in select * from jsonb_array_elements(p_items)
  loop
    product_id := (item->>'id')::bigint;
    qty := (item->>'quantity')::integer;

    if product_id is null or qty is null or qty <= 0 then
      raise exception 'Producto o cantidad inválida.';
    end if;

    update products
    set stock = stock - qty
    where id = product_id
      and stock >= qty
    returning stock into new_stock;

    if not found then
      raise exception 'Stock insuficiente para el producto %.', product_id;
    end if;

    result := result || jsonb_build_array(
      jsonb_build_object(
        'id', product_id,
        'stock', new_stock
      )
    );
  end loop;

  return result;
end;
$$;

revoke all on function public.decrement_stock(jsonb) from public;
grant execute on function public.decrement_stock(jsonb) to anon;
grant execute on function public.decrement_stock(jsonb) to authenticated;
