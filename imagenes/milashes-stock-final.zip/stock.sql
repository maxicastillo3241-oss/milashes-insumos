-- MILASHES INSUMOS - descuento seguro de stock
-- Ejecutar una sola vez en Supabase > SQL Editor

create or replace function public.decrement_product_stock(items jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  item jsonb;
  product_id bigint;
  quantity integer;
  current_stock integer;
begin
  if jsonb_typeof(items) <> 'array' then
    raise exception 'Formato de productos inválido.';
  end if;

  for item in select * from jsonb_array_elements(items)
  loop
    product_id := (item ->> 'id')::bigint;
    quantity := (item ->> 'quantity')::integer;

    if product_id is null or quantity is null or quantity <= 0 then
      raise exception 'Producto o cantidad inválida.';
    end if;

    select coalesce(stock, 0)
      into current_stock
      from public.products
      where id = product_id
      for update;

    if not found then
      raise exception 'El producto % no existe.', product_id;
    end if;

    if current_stock < quantity then
      raise exception 'No hay stock suficiente para el producto %. Stock disponible: %, solicitado: %.', product_id, current_stock, quantity;
    end if;

    update public.products
       set stock = current_stock - quantity
     where id = product_id;
  end loop;

  return jsonb_build_object('success', true);
end;
$$;

grant execute on function public.decrement_product_stock(jsonb) to anon, authenticated;
